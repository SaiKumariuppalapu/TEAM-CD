package com.hack.game;

import javax.swing.*;

public class Card extends JButton {
    private int id;
    private boolean flipped;
    private boolean matched;
    private ImageIcon frontIcon;
    private ImageIcon backIcon;

    public Card(int id) {
        this.id = id;
        this.flipped = false;
        this.matched = false;
        this.frontIcon = Utils.getFlagImage(id);
        this.backIcon = new ImageIcon("resources/back.png");
        setIcon(backIcon);
    }

    public int getId() {
        return id;
    }

    public boolean isFlipped() {
        return flipped;
    }

    public void flip() {
        if (!matched) {
            flipped = !flipped;
            setIcon(flipped ? frontIcon : backIcon);
        }
    }

    public void setMatched(boolean matched) {
        this.matched = matched;
    }

    public boolean isMatched() {
        return matched;
    }
}

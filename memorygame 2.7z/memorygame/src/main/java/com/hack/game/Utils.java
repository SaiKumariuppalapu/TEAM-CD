package com.hack.game;

import javax.swing.*;
import java.net.URL;

public class Utils {
    public static ImageIcon getFlagImage(int id) {
        String[] countryCodes = {"US", "CA", "GB", "FR", "DE", "JP", "CN", "IN"};
        try {
            String code = countryCodes[id % countryCodes.length];
            URL url = new URL("https://flagsapi.com/" + code + "/flat/64.png");
            return new ImageIcon(url);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}


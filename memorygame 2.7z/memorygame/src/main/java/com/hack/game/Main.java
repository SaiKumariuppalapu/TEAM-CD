package com.hack.game;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Choose grid size
        String[] gridOptions = {"4x4", "6x6", "8x8"};
        String gridChoice = (String) JOptionPane.showInputDialog(null, "Choose grid size:", "Grid Size",
                JOptionPane.QUESTION_MESSAGE, null, gridOptions, gridOptions[0]);
        int gridSize = Integer.parseInt(gridChoice.split("x")[0]);

        // Choose number of players
        String[] playerOptions = {"1 Player", "2 Players"};
        String playerChoice = (String) JOptionPane.showInputDialog(null, "Choose number of players:", "Number of Players",
                JOptionPane.QUESTION_MESSAGE, null, playerOptions, playerOptions[0]);
        int numPlayers = playerChoice.equals("1 Player") ? 1 : 2;

        JFrame frame = new JFrame("Memory Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 800);
        frame.add(new GameBoard(gridSize, numPlayers));
        frame.setVisible(true);
    }
}

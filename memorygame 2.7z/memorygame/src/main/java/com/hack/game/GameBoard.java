package com.hack.game;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;

public class GameBoard extends JPanel {
    private ArrayList<Card> cards;
    private Card selectedCard1;
    private Card selectedCard2;
    private int gridSize;
    private int numPlayers;
    private Player[] players;
    private int currentPlayerIndex;

    public GameBoard(int gridSize, int numPlayers) {
        this.gridSize = gridSize;
        this.numPlayers = numPlayers;
        this.players = new Player[numPlayers];
        for (int i = 0; i < numPlayers; i++) {
            players[i] = new Player("Player " + (i + 1));
        }
        this.currentPlayerIndex = 0;

        setLayout(new GridLayout(gridSize, gridSize));
        cards = new ArrayList<>();

        for (int i = 0; i < (gridSize * gridSize) / 2; i++) {
            cards.add(new Card(i));
            cards.add(new Card(i));
        }

        Collections.shuffle(cards);

        for (Card card : cards) {
            add(card);
            card.addActionListener(e -> {
                if (card.isFlipped() || card.isMatched()) return;

                card.flip();

                if (selectedCard1 == null) {
                    selectedCard1 = card;
                } else if (selectedCard2 == null && card != selectedCard1) {
                    selectedCard2 = card;
                    checkMatch();
                }
            });
        }
    }

    private void checkMatch() {
        if (selectedCard1 != null && selectedCard2 != null) {
            if (selectedCard1.getId() == selectedCard2.getId()) {
                selectedCard1.setMatched(true);
                selectedCard2.setMatched(true);
                players[currentPlayerIndex].incrementScore();
                resetSelection();
                checkWinCondition();
            } else {
                Timer timer = new Timer(1000, e -> {
                    if (selectedCard1 != null) selectedCard1.flip();
                    if (selectedCard2 != null) selectedCard2.flip();
                    resetSelection();
                    switchPlayer();
                });
                timer.setRepeats(false);
                timer.start();
            }
        }
    }

    private void resetSelection() {
        selectedCard1 = null;
        selectedCard2 = null;
    }

    private void switchPlayer() {
        currentPlayerIndex = (currentPlayerIndex + 1) % numPlayers;
    }

    private void checkWinCondition() {
        boolean allMatched = cards.stream().allMatch(Card::isMatched);
        if (allMatched) {
            StringBuilder result = new StringBuilder("Game Over! Scores:\n");
            for (Player player : players) {
                result.append(player.getName()).append(": ").append(player.getScore()).append("\n");
            }
            JOptionPane.showMessageDialog(this, result.toString());
        }
    }
}

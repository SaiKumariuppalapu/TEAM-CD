# Memory Game

## 🧠 Overview
This is a Java-based memory card matching game using country flags. The game supports a 4x4 grid and can be played by one or two players.

## 🚀 Features
- 4x4 grid of cards
- Cards flip on click
- Match pairs of country flags
- Uses FlagsAPI to fetch flag images
- Simple GUI using Java Swing

## 🛠 How to Run
1. Make sure you have Java installed (JDK 8 or later).
2. Place all `.java` files in a folder named `src`.
3. Place a placeholder image named `back.png` in a folder named `resources`.
4. Compile the code:
   ```bash
   javac -d bin src/*.java
   ```
🎮 How to Play
1. Click on a card to flip it and reveal the flag.
2. Click a second card to try to find a matching flag.
3. If the flags match, the cards stay face-up.
4. If they don’t match, they flip back after a short delay.
5. Continue until all pairs are matched to win the game.
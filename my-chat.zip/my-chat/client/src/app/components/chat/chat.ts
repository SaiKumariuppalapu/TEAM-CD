import { Component } from '@angular/core';
import { SocketService } from '../../services/socket';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user';

@Component({
  selector: 'app-chat',
  imports: [FormsModule, CommonModule],
  templateUrl: './chat.html',
  styleUrl: './chat.scss',
  standalone: true
})
export class Chat {
 message = '';
  messages: any[] = [];
  username = 'guest';
  avatar = `https://picsum.photos/50?random=${Math.floor(Math.random() * 100)}`;
  selectedImageBase64: string | null = null;

  constructor(public socket: SocketService) {
    this.username = localStorage.getItem('chatUser') || 'guest';

    // Listen for incoming messages and push to messages array
    this.socket.receive().subscribe((msg) => this.messages.push(msg));
  }

  send() {
    // Prevent empty send without text or image
    if (!this.message.trim() && !this.selectedImageBase64) return;

    const msgObj: any = {
      user: this.username,
      avatar: this.avatar,
      text: this.message.trim(),
    };

    // Add image if present
    if (this.selectedImageBase64) {
      msgObj.image = this.selectedImageBase64;
    }

    // Show message immediately in chat UI
    this.messages.push(msgObj);

    // Send via websocket
    this.socket.send(msgObj);

    // Reset inputs
    this.message = '';
    this.selectedImageBase64 = null;
  }

  onImageSelected(event: Event) {
    const input = event.target as HTMLInputElement;

    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();

      reader.onload = () => {
        this.selectedImageBase64 = reader.result as string;
      };

      reader.readAsDataURL(file);
    }
  }
}

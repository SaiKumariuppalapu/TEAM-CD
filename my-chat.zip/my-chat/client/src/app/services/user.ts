import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class UserService {
  user: any;

  constructor(private http: HttpClient) {}

  async loadUser(): Promise<void> {
    const res: any = await this.http.get('https://randomuser.me/api/').toPromise();
    this.user = res.results[0];
  }

  get username() {
    return this.user?.login?.username || 'guest';
  }

  get avatar() {
    return this.user?.picture?.thumbnail || 'https://picsum.photos/50';
  }
}

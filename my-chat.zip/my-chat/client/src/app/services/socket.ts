// client/src/app/services/socket.service.ts
import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
  export class SocketService {
  private socket: Socket;

  constructor() {
    this.socket = io('http://localhost:3000'); // Your server URL
  }

  send(msg: any) {
    this.socket.emit('send-message', msg);
  }

  receive(): Observable<any> {
    return new Observable(observer => {
      this.socket.on('receive-message', (data) => {
        observer.next(data);
      });
    });
  }
}
